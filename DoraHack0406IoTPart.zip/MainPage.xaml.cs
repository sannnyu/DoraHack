﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Gpio;
using System.Diagnostics;
using System.Net;



// https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x804 上介绍了“空白页”项模板

namespace DoraHack0406IoTPart
{
    /// <summary>
    /// 可用于自身或导航至 Frame 内部的空白页。
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private GpioPin sensor;
        DispatcherTimer timer;
        GpioPinValue Gvalue;
        //DispatcherTimer switchKeyTimer;
        public int count = 0;
        public MainPage()
        {
            this.InitializeComponent();
            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Tick += Timer_Tick;//每秒触发这个事件，以刷新指针
            timer.Start();

            //switchKeyTimer = new DispatcherTimer();
            //switchKeyTimer.Interval = new TimeSpan(0, 0, 1);
            //switchKeyTimer.Tick += switchKeyTimer_Tick;//每秒触发这个事件，以刷新指针
            //switchKeyTimer.Start();
        }
        //private void switchKeyTimer_Tick(object sender, object e)
        //{


        //}
        private void Timer_Tick(object sender, object e)
        {
            Random r = new Random();
            int temp = r.Next(27, 40);
            var value = sensor.Read();
            if(value!=Gvalue)
            {
                Debug.WriteLine("GPIO Changed" + temp);
                Post(temp, "FALSE", "1");

                //这里可以发了
                //NotificationHubClient hub = NotificationHubClient.CreateClientFromConnectionString("<connection string with full access>", "<hub name>");
                //string toast = @"<toast><visual><binding template=""ToastText01""><text id=""1"">Hello from a .NET App!</text></binding></visual></toast>";
                //await hub.SendWindowsNativeNotificationAsync(toast);
                //发生改变了
            }

            Gvalue = value;
            
            //switch (value)
            //{
            //    case GpioPinValue.Low:
            //        //低电平
            //        //只通知disconnected
            //        Debug.WriteLine("NO no no" + temp);
            //        break;
            //    case GpioPinValue.High:
            //        //高电平 上传当前的温度，并做通知
            //        //状态改变时

            //        Debug.WriteLine("Yes" + temp);
            //        //这是默认


            //        break;
            //    default:
            //        //其他情况
            //        Debug.WriteLine("Something wrong has happened\t" + temp);
            //        break;

            //}
        }
        //传感器功能 -完成
        //发送到网页功能 -
        //推送功能
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var gpio = GpioController.GetDefault();
            sensor = gpio.OpenPin(3);
            sensor.SetDriveMode(GpioPinDriveMode.Input);

        }



        public async void Post(int temp,string sensor,string id)
        {
            string con = "https://prod-24.westus.logic.azure.com:443/workflows/5a805b46998a4df3870a181c3251d089/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=a3eZXQ7wbNX7f4qn4Oa-DGCuXOkupn5qeJflvUq7vtM";


            string datas = "{\n\t\"Temp\":\"" + temp + "\",\n\t\"sensor\":\"" + sensor + "\",\n\t\"id\":\"" + id + "\"\n}";




            var request = WebRequest.Create(con);
            request.ContentType = "application/json";
            request.Method = "POST";
            if (sensor != "")
            {
                using (var requestStream = await request.GetRequestStreamAsync())
                {
                    var writer = new StreamWriter(requestStream);
                    writer.Write(datas);
                    writer.Flush();

                }
                using (var resp = await request.GetResponseAsync())
                {
                    using (var responseStream = resp.GetResponseStream())
                    {
                        var reader = new StreamReader(responseStream);
                        var result = reader.ReadToEnd();
                        //temp=result.ToString();
                    }
                }

            }
        }
    }
}
